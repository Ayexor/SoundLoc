/*
 * Empty C++ Application
 */

#include "xil_printf.h"
#include "xparameters.h"
#include "SDM_Dezimator.h"
#include "AXI_SH_595.h"
#include "xintc.h"

#define SIZE (3 * 19000)
const int DECIMATION = 125;
s16 val[SIZE]; 	// pointer to stored values
int top; // index to topmost element in val[]. initialized to SIZE! Decrement by pushing values

const int CIC = XPAR_CIC_S_AXI_BASEADDR;
const int SH = XPAR_SH_S_AXI_BASEADDR;

int irg_flag;

void logVal(XIntc* pIntc);
void isr(void* arg);

int main() {
	XIntc intc;
	int result;
	SDM_DECIM_setStatus(CIC, 0x0); // reset

	AXI_SH_595_init(SH, 0x1);
	while(!AXI_SH_595_ready(SH));
	AXI_SH_595_programm_sh(SH, 1 << 15);

	if(intc.IsStarted == XIL_COMPONENT_IS_STARTED)
		XIntc_Stop(&intc);
	result = XIntc_Initialize(&intc, XPAR_INTC_0_DEVICE_ID);
	if (result != XST_SUCCESS)
		xil_printf("IRQ Initialization failed\n");
	result = XIntc_Start(&intc, XIN_REAL_MODE);
	if(result !=XST_SUCCESS)
		xil_printf("IRQ start failed\n");
	result = XIntc_Connect(&intc, XPAR_INTC_CIC_IRQ_NEW_VAL_INTR, isr, &intc);
	if(result !=XST_SUCCESS)
		xil_printf("IRQ connection failed\n");

	logVal(&intc);


	return 0;
}

void logVal(XIntc* pIntc) {
	register int delay;
	while(!AXI_SH_595_ready(SH));
	AXI_SH_595_programm_sh(SH, 1 << 14);

	while(!AXI_SH_595_ready(SH));
	AXI_SH_595_programm_sh(SH, 1 << 13);
	SDM_DECIM_setStatus(CIC, 0xD); // run, IRQ ena and 3rd Order
	SDM_DECIM_setDecimation(CIC, DECIMATION);

	while(!AXI_SH_595_ready(SH));
	AXI_SH_595_programm_sh(SH, 1 << 12);

	XIntc_Enable(pIntc, XPAR_INTC_CIC_IRQ_NEW_VAL_INTR);

	top = SIZE;
	while (top > 2) {
//		while(irg_flag) ;
		delay = DECIMATION * 40;
		while(--delay);

//		irg_flag = 1;
		if (top >2){
		val[top - 0] = (s16) SDM_DECIM_getValue(CIC, 1);
		val[top - 1] = (s16) SDM_DECIM_getValue(CIC, 2);
		val[top - 2] = (s16) SDM_DECIM_getValue(CIC, 3);
		top = top - 3;
		}
	}
	XIntc_Disable(pIntc, XPAR_INTC_CIC_IRQ_NEW_VAL_INTR);
	while(!AXI_SH_595_ready(SH));
	AXI_SH_595_programm_sh(SH, 1 << 11);
	top = SIZE;
	while (top > 2) {
		xil_printf("%d,%d,%d\n", val[top], val[top - 1], val[top - 2]);
		top = top - 3;
	}

	while(!AXI_SH_595_ready(SH));
	AXI_SH_595_programm_sh(SH, 0);
}

void isr(void* arg){
	XIntc_Acknowledge(arg, XPAR_INTC_CIC_IRQ_NEW_VAL_INTR);
	xil_printf("IRQ");
	irg_flag = 0;
}
