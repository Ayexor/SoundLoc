/***************************** Include Files *******************************/
#include "ArtyIO.h"
#include "xparameters.h"
#include "stdio.h"
#include "xil_io.h"

/************************** Constant Definitions ***************************/
const u32 testVal[13] = { 0xAAAAaaaa,	// CTRL
		0xffff,		// IPR
		0x55555555,	// SET CTRL
		0xFFFFffff,	// CLEAR CTRL
		0x0,		// SW BTN
		0x1,		// LED
		0x2,		// LED SET
		0x3,		// LED CLEAR
		0xFFffFF,	// RGB0
		0xFFffFF,	// RGB1
		0xFFffFF,	// RGB2
		0xFFffFF,	// RGB3
		0xFF,		// RGB_Y
		};

const u32 expRes[13] = { 0xAAAAaaaa,	// CTRL
		0x0000,		// IPR
		0xFFFFffff,	// SET CTRL
		0x00000000,	// CLEAR CTRL
		0xF0,		// SW BTN
		0x1,		// LED
		0x3,		// LED SET
		0x0,		// LED CLEAR
		0xFFffFF,	// RGB0
		0xFFffFF,	// RGB1
		0xFFffFF,	// RGB2
		0xFFffFF,	// RGB3
		0xFF,		// RGB_Y
		};

const u32 WriteAddr[13] = { 0x00,	// CTRL
		0x04,	// IPR
		0x08,	// SET CTRL
		0x0C,	// CLEAR CTRL
		0x10,	// SW BTN
		0x14,	// LED
		0x18,	// LED SET
		0x1C,	// LED CLEAR
		0x20,	// RGB0
		0x24,	// RGB1
		0x28,	// RGB2
		0x2C,	// RGB3
		0x30	// RGB_Y
		};

const u32 readAddr[13] = { 0x00,	// CTRL
		0x04,	// IPR
		0x00,	// SET CTRL
		0x00,	// CLEAR CTRL
		0x10,	// SW BTN
		0x14,	// LED
		0x14,	// LED SET
		0x14,	// LED CLEAR
		0x20,	// RGB0
		0x24,	// RGB1
		0x28,	// RGB2
		0x2C,	// RGB3
		0x30	// RGB_Y
		};

#define BASE XPAR_ARTYIO_S00_AXI_BASEADDR
/************************** Function Definitions ***************************/
/**
 *
 * Run a self-test on the driver/device. Note this may be a destructive test if
 * resets of the device are performed.
 *
 * If the hardware system is not built correctly, this function may never
 * return to the caller.
 *
 * @param   baseaddr_p is the base address of the ARTYIOinstance to be worked on.
 *
 * @return
 *
 *    - XST_SUCCESS   if all self-test code passed
 *    - XST_FAILURE   if any self-test code failed
 *
 * @note    Caching must be turned off for this function to work.
 * @note    Self test may fail if data memory and device are not on the same bus.
 *
 */
XStatus ARTYIO_Reg_SelfTest() {
	int index;
	int result;
	int delay;


	xil_printf("******************************\n\r");
	xil_printf("* User Peripheral Self Test\n\r");
	xil_printf("******************************\n\n\r");

	/*
	 * Write to user logic slave module register(s) and read back
	 */
	xil_printf("User logic slave module test...\n\n");

	for (index = 0; index < 13; index++) {
		ARTYIO_mWriteReg(BASE, WriteAddr[index], testVal[index]);

		delay = 100;
		while (--delay);

		result = ARTYIO_mReadReg(BASE, readAddr[index]);

		if (result != expRes[index]) {
			xil_printf("Wrong value %x at %x\n", result, readAddr[index]);
		} else {
			xil_printf("Correct value %x at %x\n", result, readAddr[index]);
		}
	}

	xil_printf("   - slave register write/read passed\n\n\r");

	return XST_SUCCESS;
}
