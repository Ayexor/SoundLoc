/*******************************************************************************
 Associated Filename: xcorr.c
 Purpose: Crosscorrelation of microphone data for project SoundLoc
 Device: Artix7, Zynq7
 Revision History: January 29, 2016 - initial release
 *******************************************************************************/

#include <stdio.h>
#include "xcorr.h"

/*
 * Main function
 *
 * - store mic data
 * - calculate cross correlation
 * - return tau_max where xcorr is largest
 */
void XCorr(const mic_data_t mic_in[3], int tau[2], unsigned int treshold) {
#if (0)
#pragma HLS INTERFACE s_axilite port=return
#else
#pragma HLS INTERFACE ap_ctrl_hs port=return
#endif

#pragma HLS ARRAY_PARTITION variable=mic_in complete dim=1

	static int tau_max[2] = { 0, 0 }; // tau where xcorr is largest
	static int next_sample = 0; // where to store the next sample
#pragma HLS RESET variable=tau_max
#pragma HLS RESET variable=next_sample

	static mic_ram_t mic_ram;	// RAM for mic data
	static xcorr_ram_t xcorr_ram;	// RAM for cross correlation
#pragma HLS ARRAY_PARTITION variable=mic_ram complete dim=1

	// Start of new Frame?
	if (next_sample == 0) {
		XCorr_clear_ram(xcorr_ram);
	}
	// Store new mic values
	XCorr_store_mic(mic_ram, mic_in, next_sample);

	/*
	 * calculate cross correlation of newest value
	 * if enough values have been stored
	 * */
	if (next_sample >= TAU_MAX)
		XCorr_calculate(mic_ram, next_sample, xcorr_ram);

	// increment sample count and check for complete frame
	if (next_sample == MIC_SAMPLE_CNT - 1) {
		next_sample = 0;
		XCorr_find_max(xcorr_ram, treshold, tau_max);
	} else {
		next_sample++;
	}

	tau[0] = tau_max[0];
	tau[1] = tau_max[1];

//	if ((debug_at == next_sample) || (next_sample == 0))
//		XCorr_dump_xcorr_ram(xcorr_ram);
}

/*
 * Clears RAM
 */
void XCorr_clear_ram(xcorr_ram_t xcorr_ram) {
#pragma HLS INLINE
	int idx, corr;
	clear_loop: for (idx = 0; idx < 2 * TAU_MAX + 1; idx++) {
		inner: for (corr = 0; corr < 2; corr++) {
			xcorr_ram[corr][idx] = 0;
		}
	}
}

/*
 * Store mic_in in mic_ram for further processing
 */
void XCorr_store_mic(mic_ram_t mic_ram, const mic_data_t mic_in[3],
		int sample_index) {
#pragma HLS INLINE
	int mic;

	mic_loop: for (mic = 0; mic < 3; mic++) {
#pragma HLS UNROLL
		// Store new data in RAM
		mic_ram[mic][sample_index] = mic_in[mic];
	}
}

/* Add correlation of new mic values to xcorr_ram
 *
 * n is the index of the newest value in mic_ram
 */
void XCorr_calculate(const mic_ram_t mic_ram, const int n,
		xcorr_ram_t xcorr_ram) {

	int tau, corr;
	int xcorr, mac;

	/* Loop for tau */
	tau_loop: for (tau = -TAU_MAX; tau <= TAU_MAX; tau++) {
		inner: for (corr = 0; corr < 2; corr++) {
			xcorr = xcorr_ram[corr][tau + TAU_MAX];
			if (tau > 0) { // Positive tau
				mac = mic_ram[0][n - tau] * mic_ram[corr + 1][n];
			} else { // Non-positive tau
				mac = mic_ram[0][n]	* mic_ram[corr + 1][n + tau];
			}
			xcorr_ram[corr][tau + TAU_MAX] = mac + xcorr;
		}
	}
}

/*
 * Store xcorr_ram in xcorr_ram_reg, so that is is available for further processing
 */
void XCorr_reg_xcorr_ram(xcorr_ram_t xcorr_ram_reg, const xcorr_ram_t xcorr_ram) {
	int idx;
	reg_loop: for (idx = 0; idx < 2 * TAU_MAX + 1; idx++) { // -TAU_MAX:TAU_MAX := 2*TAU_MAX + 1 Values
		xcorr_ram_reg[0][idx] = xcorr_ram[0][idx];
		xcorr_ram_reg[1][idx] = xcorr_ram[1][idx];
	}
}

void XCorr_find_max(const xcorr_ram_t xcorr_ram_reg, unsigned int treshold,
		int tau_max[2]) {
	int tau, corr, tmp;
	int max[2];  // max tau
	int xcorr[2]; // value of max tau

// Initialize
	init: for (corr = 0; corr < 2; corr++) {
		max[corr] = -TAU_MAX;
		xcorr[corr] = xcorr_ram_reg[corr][0];
	}

// Iterate
	find_max: for (tau = -TAU_MAX + 1; tau <= TAU_MAX; tau++) {
		inner: for (corr = 0; corr < 2; corr++) {
			tmp = xcorr_ram_reg[corr][tau + TAU_MAX];
			if (xcorr[corr] < tmp) {
				max[corr] = tau;
				xcorr[corr] = tmp;
			}
		}
	}

	if (xcorr[0] < treshold || xcorr[1] < treshold) {
		tau_max[0] = 0;
		tau_max[1] = 0;
	} else {
		tau_max[0] = max[0];
		tau_max[1] = max[1];
	}
}

/*
 * Print out content of RAM for debuging
 */
//void XCorr_dump_xcorr_ram(xcorr_ram_t xcorr) {
//	int tau;
//
//	printf("*******************************************\n");
//	printf("* DEBUG PRINT OF XCORR DATA ***************\n");
//	printf("*******************************************\n");
//	for (tau = -TAU_MAX; tau <= TAU_MAX; tau++) {
//		printf("XCorr_ram[:][%3d] = [%9d, %9d]\n", tau, xcorr[0][tau + TAU_MAX],
//				xcorr[1][tau + TAU_MAX]);
//	}
//	printf("*******************************************\n\n");
//}
