/*******************************************************************************
 Associated Filename: xcorr.h
 Purpose: Crosscorrelation of microphone data for project SoundLoc
 Device: Artix7, Zynq7
 Revision History: January 29, 2016 - initial release
 *******************************************************************************/

#ifndef X_CORR_H_
#define X_CORR_H_

/* Defines */
#define MIC_SAMPLE_CNT	(1000) //for debug - release with 1024
#define TAU_MAX (15)

/* Type definitions */
typedef short mic_data_t;
typedef mic_data_t mic_ram_t[3][MIC_SAMPLE_CNT];

typedef int xcorr_t;
typedef xcorr_t xcorr_ram_t[2][2*TAU_MAX + 1];

/* Functions */

void XCorr(const mic_data_t mic_in[3], int tau[2], unsigned int treshold);

void XCorr_clear_ram(xcorr_ram_t xcorr_ram);
void XCorr_store_mic(mic_ram_t mic_ram, const mic_data_t mic_in[3], int sample_index);
void XCorr_calculate(const mic_ram_t mic_ram, int n, xcorr_ram_t xcorr_ram);
void XCorr_reg_xcorr_ram(xcorr_ram_t xcorr_ram_reg, const xcorr_ram_t xcorr_ram);
void XCorr_find_max(const xcorr_ram_t xcorr_ram_reg, unsigned int treshold, int tau_max[2]);
//void XCorr_dump_xcorr_ram(xcorr_ram_t xcorr);

#endif
