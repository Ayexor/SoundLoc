/*******************************************************************************
 Associated Filename: xcorr_test.c
 Purpose: Crosscorrelation of microphone data for project SoundLoc
 Device: Artix7, Zynq7
 Revision History: January 29, 2016 - initial release
 *******************************************************************************/
#include <stdio.h>
#include <math.h>
#include "xcorr.h"

/* Function prototypes */
void generate_signal(const int exp_tau[2], short signal[3][MIC_SAMPLE_CNT]);
void comp_results(const int exp_tau[2], const int tau[2], int *err_cnt);

int main() {
	const int SAMPLES = 4000;
	const int treshold = 2000;
	FILE *fp;

	const int exp_tau[2] = { -8, 6 }; // expected result
	int tau[2]; // result

	mic_data_t mic_in[3];			// input to xcorr
	short signal[3][MIC_SAMPLE_CNT];	// test signal

	int sample, mic, idx; // index variables
	int err_cnt = 0;

	// generate Signal
	generate_signal(exp_tau, signal);

	fprintf(stdout, "*******************************************\n");
	printf("\nComparing result against expected data \n");
	fprintf(stdout, "*******************************************\n");

	for (sample = 1; sample <= SAMPLES; sample++) {

		for (mic = 0; mic < 3; mic++) {
			mic_in[mic] = signal[mic][(sample-1) % MIC_SAMPLE_CNT];
		}

		// Execute the function with latest input
		XCorr(mic_in, tau, treshold);

		if (!(sample%MIC_SAMPLE_CNT) && (sample))
			comp_results(exp_tau, tau, &err_cnt);

		// Save the results.
	}

	if (err_cnt) {
		fprintf(stdout, "FAIL: Found a total of %d errors! \n", err_cnt);
		fprintf(stdout, "*******************************************\n\n");
		return err_cnt;
	} else {
		fprintf(stdout, "PASS: The output matches the golden output!\n");
		fprintf(stdout, "*******************************************\n\n");
		return 0;
	}
}

void generate_signal(const int exp_tau[2], short signal[3][MIC_SAMPLE_CNT]) {
	int idx;

	/* cosin param */
	const double w = 0.5;
	const double A = 12.5;
	/* Dirac parameters */
	const int offset = 16;
	const int period = 32;

	for (idx = 0; idx < MIC_SAMPLE_CNT; idx++) {
//		signal[0][idx] = (idx % period == offset) ? 1 : 0;
//		signal[1][idx] = (idx % period == offset + exp_tau[0]) ? 1 : 0;
//		signal[2][idx] = (idx % period == offset + exp_tau[1]) ? 1 : 0;

		signal[0][idx] = (short) (A * cos(w * (idx)));
		signal[1][idx] = (short) (A * cos(w * (idx - exp_tau[0])));
		signal[2][idx] = (short) (A * cos(w * (idx - exp_tau[1])));
	}
}

void comp_results(const int exp_tau[2], const int tau[2], int* err_cnt){
	int idx;
	for (idx = 0; idx < 2; idx++) {
		if (exp_tau[idx] != tau[idx]) {
			printf("Error: mismatch in tau[%d]! got: %3d, exp.: %3d\n", idx,
					tau[idx], exp_tau[idx]);
			(*err_cnt)++;
		} else {
			printf("Result: match tau[%d] got: %3d, exp.: %3d\n", idx, tau[idx],
					exp_tau[idx]);
		}
	}
	fprintf(stdout, "*******************************************\n");
}
