/*
 * XCorrTest.h
 *
 *  Created on: 25.11.2016
 *      Author: Roy
 */

#ifndef XCORR_TEST_H_
#define XCORR_TEST_H_

//#include "xgpio.h"
//#include "sig.h"
//#include "XCorr.h"
//#include "AXI_SH_595.h"
//
//#define SIZE 5
//#define TAU_MAX 32
//#define SH 			XPAR_SH_S_AXI_BASEADDR
//#define XCORR		XPAR_XCORR_0_S_AXI_BASEADDR
//
//typedef struct {
//	int corr01[TAU_MAX];
//	int corr02[TAU_MAX];
//} TauStore ;
//
//void genTau();
//void clearRam();
//void logTau(int store);
//void printTau();
//void setMic(int micNr, int x);
//void setAllMic(int x);
//void test();
//void pulseIrq(void);


#endif /* XCORR_TEST_H_ */
